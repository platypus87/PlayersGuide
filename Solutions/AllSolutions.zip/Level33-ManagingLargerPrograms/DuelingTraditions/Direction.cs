﻿namespace DuelingTraditions
{
    // Represents one of the four directions of movement.
    public enum Direction { North, South, West, East }
}