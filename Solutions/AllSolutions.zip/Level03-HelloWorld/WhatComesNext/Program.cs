﻿using System;

Console.WriteLine("Help me, Obi-Wan Kenobi. You're my only hope.");