﻿public interface IGear
{
    string Name { get; }
    IAttack Attack { get; }
}
